To run the programm extract CoreMethods.py, TestGround.py and the folder cardata to the same location.
start your python3 console, navigate to this location and import the TestGorund (>>>import TestGround.py)
That's it.