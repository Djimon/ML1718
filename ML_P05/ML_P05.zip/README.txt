To run the programm extract CoreMethods.py, TestGround.py and the folder cardata to the same location.
start your python3 console, navigate to this location and import the TestGorund (>>>import TestGround.py)
the programm asks you to input a number representing the k in m-neares-neighbour. 
after typing the number ent pressing enter, the program will learn, predict and output the results, encluding error-rate